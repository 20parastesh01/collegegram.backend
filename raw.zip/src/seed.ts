import { v4 } from 'uuid'
import { AppDataSource } from './data-source'
import { SampleEntity } from './modules/sample/entity/sample.entity'
export const seed = async () => {}
