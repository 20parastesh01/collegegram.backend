import { NextFunction, Request, Response } from 'express'
import multer from 'multer'

const multerStorage = multer.memoryStorage()

const multerFilter = (req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    if (!file.mimetype.startsWith('image')) {
        return cb(new multer.MulterError('LIMIT_UNEXPECTED_FILE'))
    }

    cb(null, true)
}

const upload = multer({
    storage: multerStorage,
    fileFilter: multerFilter,
    limits: { fileSize: 5000000, files: 1 },
})

export const uploadPostImage = upload.single('image')
