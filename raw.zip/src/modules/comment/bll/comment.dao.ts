import { zodWholeNumber } from '../../../data/whole-number'
import { zodUserShort } from '../../user/model/user'
import { CommentWithDetail, CreateComment } from '../comment.repository'
import { CommentEntity } from '../entity/comment.entity'
import { NewComment, Comment } from '../model/comment'

const convertToModel = (entity: CommentWithDetail) => {
    const { updatedAt, author, ...rest } = entity
    return { author: zodUserShort.parse( {photo:'', ...author}), ...rest }
}

export const commentDao = (input: CommentEntity) => {
    return {
        toCommentModel(): Comment | undefined {
            const { updatedAt, author, ...rest } = input
            return { author: zodUserShort.parse( {photo:'', ...author}), likeCount: zodWholeNumber.parse(0) ,...rest }
        },
    }
}
export const commentListDao = (input: CommentWithDetail[]) => {
    return {
        toCommentModelList(): Comment[] {
            // Handle the case when input is an array of PostEntity
            //trow error
            return input.map((entity) => {
                return convertToModel(entity)
            })
        },
    }
}
export const commentOrNullDao = (input: CommentWithDetail | null) => {
    return {
        toCommentModel(): Comment | undefined {
            if (input === null) return undefined
            else {
                return convertToModel(input)
            }
        },
    }
}

export const toCreateComment = (comment: NewComment): CreateComment => {
    const { parentId, ...rest } = comment
    const createCommentEntity: CreateComment = {
        ...rest,
        parentId
    }

    return createCommentEntity
}
