import { Email } from '../../../data/email'
import { Token } from '../../../data/token'
import { SampleId } from './sample-id'

export interface Sample {
    id: SampleId
}
